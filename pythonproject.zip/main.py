import pygame

import pygame
from guy import Guy
from platform import Platform

# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 15)
pygame.display.set_caption("")

# set up variables for the display
SCREEN_HEIGHT = 370
SCREEN_WIDTH = 530
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)

name = ""
message = ""
r = 50
g = 0
b = 100

# render the text for later
display_name = my_font.render(name, True, (255, 255, 255))
display_message = my_font.render(message, True, (255, 255, 255))

guy = Guy(40, 60)
plat = Platform(200, 85)

# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True

# -------- Main Program Loop -----------
while run:

    keys = pygame.key.get_pressed()  # checking pressed keys
    if keys[pygame.K_d]:
        guy.move_direction("right")
    if keys[pygame.K_a]:
        guy.move_direction("left")
    if keys[pygame.K_w]:
        guy.move_direction("up")
    if keys[pygame.K_s]:
        guy.move_direction("down")

    # collision
    if guy.rect.colliderect(plat.rect):
        message = "Collision detected"
        guy.y = 60
        display_message = my_font.render(message, True, (255, 255, 255))
    else:
        message = "Collision not detected"
        display_message = my_font.render(message, True, (255, 255, 255))

    # --- Main event loop
    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False

    screen.fill((r, g, b))
    screen.blit(display_name, (0, 0))
    screen.blit(display_message, (0, 15))
    screen.blit(guy.image, guy.rect)
    screen.blit(plat.image, plat.rect)
    pygame.display.update()

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()



