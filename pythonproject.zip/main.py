import pygame

import pygame
from guy import Guy
from platform import Platform
from enemy import Enemy
from bullet import Bullet
from spike import Spike
import random

# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 15)
pygame.display.set_caption("")

# set up variables for the display
bg = pygame.image.load("background.png")
SCREEN_HEIGHT = 720
SCREEN_WIDTH = 1080
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)

name = ""
red = 50
green = 0
blue = 100

# render the text for later
display_name = my_font.render(name, True, (255, 255, 255))
j = 0
z = 0
plat_list = pygame.sprite.Group()
guy = Guy(40, 60)
enemy = Enemy(1000, random.randint(300, 600))
bullets = []
for i in range(5):
    plat = Platform(0 + j, 500 - z)
    plat_list.add(plat)
    j += 300
    z += 50

bullets = []
# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
not_collide_count = 0
clock = pygame.time.Clock()
fps = 0
jumpCount = 0
jumpMax = 17.5
enemy_dead = False

# -------- Main Program Loop -----------
while run:

    clock.tick(60)
    guy.rect = pygame.Rect(guy.x, guy.y, guy.image_size[0], guy.image_size[1])
    enemy.rect = pygame.Rect(guy.x + 750, guy.y, enemy.image_size[0], enemy.image_size[1])

    if guy.y > 720:
        guy.y = -50

    for bullet in bullets:
        
        bullet.x += bullet.x_vel
        bullet.rect = pygame.Rect(bullet.x, bullet.y, bullet.image_size[0], bullet.image_size[1])
        if bullet.destroy:
            bullets.remove(bullet)

    keys = pygame.key.get_pressed()  # checking pressed keys

    for plat in plat_list:

        if keys[pygame.K_d]:
            plat.x -= guy.delta
        if keys[pygame.K_a]:
            plat.x += guy.delta
        plat.rect = pygame.Rect(plat.x, plat.y, plat.image_size[0], plat.image_size[1])

        if plat.x < -250:
            plat.x = 1200
            plat.y = random.randint(300, 600)

        if guy.rect.colliderect(plat.rect):
            guy.rect.bottom = plat.rect.top
            guy.is_Jumping = False
            not_collide_count = 0

        elif not guy.rect.colliderect(plat.rect):
            not_collide_count += 1
            if not_collide_count == len(plat_list):
                guy.is_Jumping = True

    if fps % 60 == 0 and not enemy_dead:
        e_bullet = Bullet(enemy.rect.centerx, enemy.rect.centery, -1, [enemy, guy], enemy)
        bullets.append(e_bullet)

    # --- Main event loop
    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not guy.is_Jumping:
                guy.is_Jumping = True
                jumpCount = jumpMax

        if event.type == pygame.MOUSEBUTTONDOWN:
            if guy.current_direction == "right":
                bullet = Bullet(guy.rect.centerx, guy.rect.centery, 1, [enemy, guy], guy)
            else:
                bullet = Bullet(guy.rect.centerx, guy.rect.centery, -1, [enemy, guy], guy)
            bullets.append(bullet)

    if guy.is_Jumping:
        guy.y -= jumpCount
        if jumpCount > -jumpMax:
            jumpCount -= 1

    screen.fill((red, green, blue))
    screen.blit(bg, (0, 0))
    screen.blit(display_name, (0, 0))
    screen.blit(guy.image, guy.rect)

    if enemy.health > 0:
        screen.blit(enemy.image, enemy.rect)
    if enemy.health <= 0:
        enemy_dead = True
        enemy.x = 100000
        enemy.y = 100000
        enemy.rect = pygame.Rect(enemy.x, enemy.y, enemy.image_size[0], enemy.image_size[1])
    for plat in plat_list:
        screen.blit(plat.image, plat.rect)
    for bullet in bullets:
        screen.blit(bullet.image, bullet.rect)
        bullet.update()
    guy.gravity()
    pygame.display.update()
    fps += 1

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()



