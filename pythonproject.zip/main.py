import pygame

import pygame
from guy import Guy
from platform import Platform
import random

# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 15)
pygame.display.set_caption("")

# set up variables for the display
bg = pygame.image.load("background.png")
SCREEN_HEIGHT = 720
SCREEN_WIDTH = 1080
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)

name = ""
message = ""
r = 50
g = 0
b = 100

# render the text for later
display_name = my_font.render(name, True, (255, 255, 255))
display_message = my_font.render(message, True, (255, 255, 255))
j = 1
plat_list = pygame.sprite.Group()
guy = Guy(40, 60)
for i in range(4):
    plat = Platform(0 + j, 500)
    plat_list.add(plat)
    j += 300

# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
not_collide_count = 0
# -------- Main Program Loop -----------
while run:

    guy.rect = pygame.Rect(guy.x, guy.y, guy.image_size[0], guy.image_size[1])
    if guy.y > 720:
        guy.y = -50


    keys = pygame.key.get_pressed()  # checking pressed keys
    if keys[pygame.K_d]:
        guy.move_direction("right")
    if keys[pygame.K_a]:
        guy.move_direction("left")

    for plat in plat_list:
        if guy.rect.colliderect(plat.rect):
            message = "Collision detected"
            guy.rect.bottom = plat.rect.top
            display_message = my_font.render(message, True, (255, 255, 255))
            guy.is_Jumping = False
            not_collide_count = 0

        elif not guy.rect.colliderect(plat.rect):
            not_collide_count += 1
            if not_collide_count == len(plat_list):
                message = "Collision not detected"
                display_message = my_font.render(message, True, (255, 255, 255))
                guy.is_Jumping = True


    # --- Main event loop
    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not guy.is_Jumping:
                guy.y -= 60
                guy.is_Jumping = True



    screen.fill((r, g, b))
    screen.blit(bg, (0, 0))
    screen.blit(display_name, (0, 0))
    screen.blit(display_message, (0, 15))
    screen.blit(guy.image, guy.rect)
    for plat in plat_list:
        screen.blit(plat.image, plat.rect)
    guy.gravity()
    pygame.display.update()

# Once we have exited the main program loop we can stop the game engine:
pygame.quit()



