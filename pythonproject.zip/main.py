import pygame

import pygame
from guy import Guy
from platform import Platform
from enemy import Enemy
from bullet import Bullet
import random

# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 15)
pygame.display.set_caption("")

# set up variables for the display
bg = pygame.image.load("background.png")
SCREEN_HEIGHT = 720
SCREEN_WIDTH = 1080
size = (SCREEN_WIDTH, SCREEN_HEIGHT)
screen = pygame.display.set_mode(size)

name = ""
red = 50
green = 0
blue = 100


def update_sprite():
    if keys[pygame.K_d]:
        if not guy.is_Jumping:
            if fps % 10 == 0:
                guy.update("walking1.png", "right")
            if fps % 20 == 0:
                guy.update("walking2.png", "right")
    if keys[pygame.K_a]:
        if not guy.is_Jumping:
            if fps % 10 == 0:
                guy.update("walking1.png", "left")
            if fps % 20 == 0:
                guy.update("walking2.png", "left")


# render the text for later
display_name = my_font.render(name, True, (255, 255, 255))
j = 0
z = 0
platforms = pygame.sprite.Group()
plat_list = []
guy = Guy(40, 60)
enemy = Enemy(1000, random.randint(50, 700))
bullets = []
for i in range(5):
    plat = Platform(0 + j, 500 - z, "platform.png")
    platforms.add(plat)

    j += 300
    z += 50

bullets = []
# The loop will carry on until the user exits the game (e.g. clicks the close button).
run = True
not_collide_count = 0
clock = pygame.time.Clock()
fps = 0
jumpCount = 0
jumpMax = 17.5
dashCount = 0
dashMax = 100
enemy_dead = False
timer = 0
delta = clock.tick(30) / 1000

# -------- Main Program Loop -----------
while run:
    keys = pygame.key.get_pressed()  # checking pressed keys
    clock.tick(60)
    guy.rect = pygame.Rect(guy.x, guy.y, guy.image_size[0], guy.image_size[1])
    update_sprite()
    enemy.x = guy.x + 750

    if guy.y > 720:
        guy.y = -50
    if enemy.y >= 650:
        enemy.direction = -1
    if enemy.y <= 50:
        enemy.direction = 1

    for bullet in bullets:
        
        bullet.x += bullet.x_vel
        bullet.rect = pygame.Rect(bullet.x, bullet.y, bullet.image_size[0], bullet.image_size[1])
        if bullet.destroy:
            bullets.remove(bullet)

    if not keys[pygame.K_d] and not keys[pygame.K_a] and not guy.is_Jumping:
        guy.update("idle.png", guy.current_direction)


    for plat in platforms:

        if keys[pygame.K_d]:
            plat.x -= guy.delta
        if keys[pygame.K_a]:
            plat.x += guy.delta


        plat.rect = pygame.Rect(plat.x, plat.y, plat.image_size[0], plat.image_size[1])

        if plat.x < -250:
            plat.x = 1200
            plat.y = random.randint(300, 600)
            plat_list.append((plat.x, plat.y))
            if len(plat_list) > 5:
                plat_list.pop(0)

        if guy.rect.colliderect(plat.rect):
            guy.rect.bottom = plat.rect.top
            guy.is_Jumping = False
            not_collide_count = 0

        elif not guy.rect.colliderect(plat.rect):
            not_collide_count += 1
            if not_collide_count == len(platforms):
                guy.is_Jumping = True

    if fps % 60 == 0 and not enemy_dead:
        e_bullet = Bullet(enemy.rect.centerx, enemy.rect.centery, -1, [enemy, guy], enemy)
        bullets.append(e_bullet)

    if timer != 0:
        timer += delta
        if timer >= .3:
            jumpMax = 17.5
            timer = 0

    # --- Main event loop
    for event in pygame.event.get():  # User did something
        if event.type == pygame.QUIT:  # If user clicked close
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not guy.is_Jumping:
                guy.is_Jumping = True
                jumpCount = jumpMax
            if timer == 0:
                timer = .001
            elif timer < .3:
                jumpMax = 22
                timer = 0

        if event.type == pygame.MOUSEBUTTONDOWN:
            if guy.current_direction == "right":
                bullet = Bullet(guy.rect.centerx, guy.rect.centery, 1, [enemy, guy], guy)
            else:
                bullet = Bullet(guy.rect.centerx, guy.rect.centery, -1, [enemy, guy], guy)
            bullets.append(bullet)

    if guy.is_Jumping:
        guy.y -= jumpCount
        if jumpCount > -jumpMax:
            jumpCount -= 1
        if jumpCount >= 0:
            guy.update("jumping1.png", guy.current_direction)
        if jumpCount < 0:
            guy.update("jumping2.png", guy.current_direction)

    screen.fill((red, green, blue))
    screen.blit(bg, (0, 0))
    screen.blit(display_name, (0, 0))
    screen.blit(guy.image, guy.rect)

    if enemy.health > 0:
        screen.blit(enemy.image, enemy.rect)
    if enemy.health <= 0:
        enemy_dead = True
        enemy.x = 100000
        enemy.y = 100000
        enemy.rect = pygame.Rect(enemy.x, enemy.y, enemy.image_size[0], enemy.image_size[1])
    for plat in platforms:
        screen.blit(plat.image, plat.rect)
    for bullet in bullets:
        screen.blit(bullet.image, bullet.rect)
        bullet.update()
    guy.gravity()
    enemy.move_y()
    pygame.display.update()
    fps += 1
# Once we have exited the main program loop we can stop the game engine:
pygame.quit()



