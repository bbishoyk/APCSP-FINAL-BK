import pygame

class Bullet:

    def __init__(self, x, y, x_direction, check, exclude):
        self.x = x
        self.y = y
        self.x_direction = x_direction
        self.check, self.exclude = check, exclude
        self.image = pygame.image.load("enemy.png")
        self.image_size = self.image.get_size()
        self.rect = pygame.Rect(self.x, self.y, self.image_size[0], self.image_size[1])
        self.damage = 1
        self.x_vel = 5 * self.x_direction
        self.destroy = False

    def update(self):
        for entity in self.check:
            if entity is not self.exclude:
                if self.rect.colliderect(entity.rect):
                    entity.health -= self.damage
                    self.destroy = True

        self.rect.move(self.x_vel, self.y)

